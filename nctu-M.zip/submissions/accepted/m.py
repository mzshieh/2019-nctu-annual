n = int(input())
x, y = 0, 0
for i in range(n):
    print(x, y)
    x += 1
    y += n-i
