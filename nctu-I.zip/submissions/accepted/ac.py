n = input()
print("1 0")
print("0 2")
print("0 "+n)
